
// Nomes e notas dos alunos
const students = [
    {nome: "Gabriel", nota: 6},
    {nome: "Bruna", nota: 3},
    {nome: "Lucas", nota: 5},
    {nome: "Maria", nota: 9},
];

// Ordenar os alunos pelo nome
function sortByName() {
    const sortedStudents = [...students].sort((a, b) => a.nome.localeCompare(b.nome));
    
    // exibir na página
    const resultDiv = document.getElementById('resultSort');
    resultDiv.innerHTML = `
        <h4>Lista Ordenada por Nome em ordem alfabética:</h4>
        <ul>
            ${sortedStudents.map(student => `<li>${student.nome} - Nota: ${student.nota}</li>`).join('')}
        </ul>
    `;
}

// Filtrar alunos com nota acima de 5
function filterByGrade() {
    const filteredStudents = students.filter(student => student.nota > 5);
    
    // exibir na página
    const resultDiv = document.getElementById('resultFilter');
    resultDiv.innerHTML = `
        <h4>Alunos com Nota Acima de 5:</h4>
        <ul>
            ${filteredStudents.map(student => `<li>${student.nome} - Nota: ${student.nota}</li>`).join('')}
        </ul>
    `;
}

// Mapear notas para uma mensagem
function mapGrades() {
    const mappedGrades = students.map(student => `${student.nome} tem nota ${student.nota}`);
    
    // exibir na página
    const resultDiv = document.getElementById('resultMap');
    resultDiv.innerHTML = `
        <h4>Mensagens das Notas:</h4>
        <ul>
            ${mappedGrades.map(message => `<li>${message}</li>`).join('')}
        </ul>
    `;
}

// Reduzir o array para a média das notas
function reduceGrades() {
    const totalGrades = students.reduce((acc, student) => acc + student.nota, 0);
    const averageGrade = totalGrades / students.length;
    
    // exibir na página
    const resultDiv = document.getElementById('resultReduce');
    resultDiv.innerHTML = `
        <h4>Média das Notas dos alunos:</h4>
        <p>Média: ${averageGrade.toFixed(2)}</p>
    `;
}

// Usar o spread e adicionar um novo aluno
function spreadExample() {
    const newStudent = {nome: "Ana", nota: 7};
    const updatedStudents = [...students, newStudent];
    
    // exibir na página
    const resultDiv = document.getElementById('resultSpread');
    resultDiv.innerHTML = `
        <h4>Lista Atualizada com Novo Aluno:</h4>
        <ul>
            ${updatedStudents.map(student => `<li>${student.nome} - Nota: ${student.nota}</li>`).join('')}
        </ul>
    `;
}